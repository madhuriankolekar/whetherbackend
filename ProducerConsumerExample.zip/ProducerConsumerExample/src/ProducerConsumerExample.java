import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProducerConsumerExample {

    public static void main(String[] args) {
    
        BlockingQueue<String> queue = new ArrayBlockingQueue<>(10);

       
        Thread producerThread = new Thread(new Producer(queue));
        producerThread.start();

        Thread consumerThread = new Thread(new Consumer(queue));
        consumerThread.start();
    }
}

class Producer implements Runnable {
    private BlockingQueue<String> queue;

    public Producer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
           
            for (int i = 1; i <= 5; i++) {
                String message = "Message " + i;
                queue.put(message);
                System.out.println("Produced: " + message);
                Thread.sleep(1000); 
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

class Consumer implements Runnable {
    private BlockingQueue<String> queue;

    public Consumer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            //Consume messages from the queue
            while (true) {
                String message = queue.take();
                System.out.println("Consumed: " + message);
                Thread.sleep(1500); 
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
